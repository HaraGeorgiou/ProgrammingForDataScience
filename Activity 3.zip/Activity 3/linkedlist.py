# 3.5 The linked list class
class Node:
    def __init__(self, data=None):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None  # Pointer to the first node in the list

    def is_empty(self):
        return self.head is None

    def is_full(self):
        return False

    def insert(self, item):
        new_node = Node(item)
        new_node.next = self.head
        self.head = new_node

    def delete(self, item):
        current = self.head
        previous = None
        while current:
            if current.data == item:
                if previous:
                    previous.next = current.next
                else:
                    self.head = current.next
                return True
            previous = current
            current = current.next
        return False

    def search(self, item):
        current = self.head
        while current:
            if current.data == item:
                return True
            current = current.next
        return False

    def traverse(self):
        items = []
        current = self.head
        while current:
            items.append(current.data)
            current = current.next
        return items

    def __str__(self):
        """Provide a string representation of the list."""
        items = []
        current = self.head
        while current:
            items.append(str(current.data))
            current = current.next
        return " -> ".join(items)
