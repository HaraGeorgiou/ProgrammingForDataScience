# 3.2 Defining operations on BSTs

import time
import random
import matplotlib.pyplot as plt
from binarysearchtree import BinarySearchTree
from linkedlist import LinkedList

def measure_time(func, *args):
    """
    Time how long a function takes to run.
    """
    start = time.time()
    func(*args)
    return time.time() - start

def random_tree(size):
    """
    Create a BST with random numbers.
    """
    bst = BinarySearchTree()
    for _ in range(size):
        bst.insert(random.randint(1, 1000))
    return bst

def random_list(size):
    """
    Create a linked list with random numbers.
    """
    ll = LinkedList()
    for _ in range(size):
        ll.insert(random.randint(1, 1000))
    return ll

def main():
    """
    Run the simulation and plot results.
    """
    sizes = list(range(5, 101, 5))
    bst_times = []
    ll_times = []

    for size in sizes:
        bst = random_tree(size)
        ll = random_list(size)
        bst_times.append(measure_time(bst.search, 42))
        ll_times.append(measure_time(ll.search, 42))

    plt.plot(sizes, bst_times, label='BST Search Time')
    plt.plot(sizes, ll_times, label='LinkedList Search Time')
    plt.xlabel('Size of Structure')
    plt.ylabel('Search Time')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()

