# Activity 3 - Binary Search Tree Functionality

#3.1 Creating the binary search tree class
class TreeNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

    def get_data(self):
        return self.data

    def set_data(self, value):
        self.data = value

    def get_left_child(self):
        return self.left

    def set_left_child(self, node):
        self.left = node

    def get_right_child(self):
        return self.right

    def set_right_child(self, node):
        self.right = node

class BinarySearchTree:
    def __init__(self, limit=None):
        self.root = None
        self.size_limit = limit

    def is_empty(self):
        return self.root is None

    def is_full(self):
        return self.size_limit is not None and self._count_nodes(self.root) >= self.size_limit

    def _count_nodes(self, node):
        if node is None:
            return 0
        else:
            return 1 + self._count_nodes(node.get_left_child()) + self._count_nodes(node.get_right_child())

# 3.2 Defining operations on BSTs
    def insert(self, data):
        if self.is_full():
            return False
        if self.root is None:
            self.root = TreeNode(data)
        else:
            self._insert_rec(self.root, data)
        return True

    def _insert_rec(self, node, data):
        if data < node.get_data():
            if node.get_left_child() is None:
                node.set_left_child(TreeNode(data))
            else:
                self._insert_rec(node.get_left_child(), data)
        else:
            if node.get_right_child() is None:
                node.set_right_child(TreeNode(data))
            else:
                self._insert_rec(node.get_right_child(), data)

    def search(self, data):
        return self._search_rec(self.root, data)

    def _search_rec(self, node, data):
        if node is None:
            return False
        if node.get_data() == data:
            return True
        elif data < node.get_data():
            return self._search_rec(node.get_left_child(), data)
        else:
            return self._search_rec(node.get_right_child(), data)

    def delete(self, data):
        self.root, deleted = self._delete_rec(self.root, data)
        return deleted

    def _delete_rec(self, node, data):
        if node is None:
            return node, False
        if data < node.get_data():
            node.left, deleted = self._delete_rec(node.get_left_child(), data)
        elif data > node.get_data():
            node.right, deleted = self._delete_rec(node.get_right_child(), data)
        else:
            if node.get_left_child() is None:
                return node.get_right_child(), True
            elif node.get_right_child() is None:
                return node.get_left_child(), True

            min_larger_node = self._get_min(node.get_right_child())
            node.data = min_larger_node.get_data()
            node.right, _ = self._delete_rec(node.get_right_child(), node.get_data())
            deleted = True
        return node, deleted

    def _get_min(self, node):
        current = node
        while current.get_left_child() is not None:
            current = current.get_left_child()
        return current

    def traverse(self):
        return self._inorder_traverse(self.root)

    def _inorder_traverse(self, node):
        result = []
        if node:
            result.extend(self._inorder_traverse(node.get_left_child()))
            result.append(node.get_data())
            result.extend(self._inorder_traverse(node.get_right_child()))
        return result

    def print_tree(self, node=None, level=0):
        if node is None:
            node = self.root
        if node is not None:
            self.print_tree(node.get_right_child(), level + 1)
            print(' ' * 4 * level + '->', node.get_data())
            self.print_tree(node.get_left_child(), level + 1)
