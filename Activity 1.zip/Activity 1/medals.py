# #Activity 1 - Analysis of Games Medal Data

# # 1.1 Creating the CountryMedals class and methods

import json
import csv
import os

filepath = 'medals.csv'
if not os.path.exists(filepath):
    raise FileNotFoundError(
        f"The required file {filepath} is missing. Please ensure it is in the same directory as this script.")


class CountryMedals:
    def __init__(self, name, gold, silver, bronze):
        self.__name = name
        self.__gold = int(gold)
        self.__silver = int(silver)
        self.__bronze = int(bronze)

    def get_gold(self):
        return self.gold

    def get_silver(self):
        return self.silver

    def get_bronze(self):
        return self.bronze

    def total_medals(self):
        return self.__gold + self.__silver + self.__bronze

    def to_json(self):
        return json.dumps({
            'name': self.__name,
            'gold': self.__gold,
            'silver': self.__silver,
            'bronze': self.__bronze,
            'total': self.total_medals()
        })

    def get_medals(self, medal_type):
        medals = {
            'gold': self.__gold,
            'silver': self.__silver,
            'bronze': self.__bronze,
            'total': self.total_medals()
        }
        return medals.get(medal_type, None)

    def print_summary(self):
        print(
            f"{self.__name} received {self.total_medals()} medals in total; {self.__gold} gold, {self.__silver} silver, and {self.__bronze} bronze.")

    def compare(self, country2):
        comparison_result = f"Medals comparison between '{self.__name}' and '{country2.__name}':\n"

        # Compare gold medals
        if self.__gold == country2.__gold:
            comparison_result += f"- Both {self.__name} and {country2.__name} received {self.__gold} gold medal(s).\n"
        else:
            comparison_difference = abs(self.__gold - country2.__gold)
            more_less = 'more' if self.__gold > country2.__gold else 'fewer'
            comparison_result += f"- {self.__name} received {self.__gold} gold medal(s), {comparison_difference} {more_less} than {country2.__name}, which received {country2.__gold} gold medal(s).\n"

        # Compare silver medals
        if self.__silver == country2.__silver:
            comparison_result += f"- Both {self.__name} and {country2.__name} received {self.__silver} silver medal(s).\n"
        else:
            comparison_difference = abs(self.__silver - country2.__silver)
            more_less = 'more' if self.__silver > country2.__silver else 'fewer'
            comparison_result += f"- {self.__name} received {self.__silver} silver medal(s), {comparison_difference} {more_less} than {country2.__name}, which received {country2.__silver} silver medal(s).\n"

        # Compare bronze medals
        if self.__bronze == country2.__bronze:
            comparison_result += f"- Both {self.__name} and {country2.__name} received {self.__bronze} bronze medal(s).\n"
        else:
            comparison_difference = abs(self.__bronze - country2.__bronze)
            more_less = 'more' if self.__bronze > country2.__bronze else 'fewer'
            comparison_result += f"- {self.__name} received {self.__bronze} bronze medal(s), {comparison_difference} {more_less} than {country2.__name}, which received {country2.__bronze} bronze medal(s).\n"

        # Compare total medals
        total_self = self.__gold + self.__silver + self.__bronze
        total_country2 = country2.__gold + country2.__silver + country2.__bronze
        total_difference = abs(total_self - total_country2)
        more_less_total = 'more' if total_self > total_country2 else 'fewer'
        comparison_result += f"Overall, {self.__name} received {total_self} medals, {total_difference} {more_less_total} than {country2.__name}, which received {total_country2} medals.\n"

        return comparison_result

# 1.2 Parsing the data
def parse_medals_csv(file_path):
    countries = {}
    with open(file_path, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            country = CountryMedals(row['Team/NOC'], row['Gold'], row['Silver'], row['Bronze'])
            countries[row['Team/NOC']] = country
    return countries


# 1.3 Creating functions to process the data

# Sorts countries in ascending order based on a specified type of medals.
def sort_countries_by_medal_type_ascending(countries, medal_type):
    if medal_type == 'total':
        return sorted(countries.values(), key=lambda x: x.total_medals())
    else:
        return sorted(countries.values(), key=lambda x: getattr(x, medal_type))


#   Sorts countries in descending order based on a specified type of medals.
def sort_countries_by_medal_type_descending(countries, medal_type):
    if medal_type == 'total':
        return sorted(countries.values(), key=lambda x: x.total_medals(), reverse=True)
    else:
        return sorted(countries.values(), key=lambda x: getattr(x, medal_type), reverse=True)


# Prompts the user to input a positive integer and validates it.
def read_positive_integer():
    while True:
        try:
            value = int(input("Enter a positive integer (0 is allowed): "))
            if value >= 0:
                return value
        except ValueError:
            print("Invalid input. Please enter a positive integer.")


# Prompts the user to input a country name and validates it against a dictionary of countries.
def read_country_name(countries):
    while True:
        country = input("Enter a country name: ")
        if country in countries:
            return country
        print("Invalid country name. Choose from the following:")
        for name in countries.keys():
            print(name)  # Each country name printed on a new line


#  Prompts the user to input a type of medal and validates it.
def read_medal_type():
    valid_types = ['gold', 'silver', 'bronze', 'total']
    while True:
        medal_type = input("Enter a medal type (gold, silver, bronze, total): ")
        if medal_type in valid_types:
            return medal_type
        print("Invalid medal type. Choose from the following:")
        for type in valid_types:
            print(type)  # Each valid medal type printed on a new line


# Filters countries based on a threshold number of specified medals.
def filter_countries_by_medal(countries, medal_type, threshold, more=True):
    result = []
    for name, country in countries.items():
        medal_count = country.get_medals(medal_type)
        if (medal_count > threshold if more else medal_count < threshold):
            result.append((name, medal_count))
    return result

# 1.4 Execution loop
def main_loop(countries):
    while True:
        command = input("Insert a command (Type 'H' for help): ").lower()
        if command == 'q':
            print("Quitting the program.")
            break
        elif command == 'h':
            print("List of commands:")
            print("- (H)elp: shows the list of commands;")
            print("- (L)ist: shows the list of countries present in the dataset;")
            print("- (S)ummary: prints out a summary of the medals won by a single country;")
            print("- (C)ompare: allows for a comparison of the medals won by two countries;")
            print("- (M)ore: given a medal type, lists all the countries that received more medals than a threshold;")
            print("- (F)ewer: given a medal type, lists all the countries that received fewer medals than a threshold;")
            print("- (E)xport: saves the medals table as a '.json' file;")
            print("- (Q)uit: exits the program.")
        elif command == 'l':
            print("The dataset contains the following countries:")
            print(', '.join(sorted(countries.keys())))
        elif command == 's':
            country_name = read_country_name(countries)
            countries[country_name].print_summary()
        elif command == 'c':
            print("Compare two countries")
            country1 = read_country_name(countries)
            country2 = read_country_name(countries)
            print(countries[country1].compare(countries[country2]))
        elif command == 'm':
            medal_type = read_medal_type()
            threshold = read_positive_integer()
            print("Countries that received more than", threshold, medal_type, "medals:")
            filtered_countries = filter_countries_by_medal(countries, medal_type, threshold, more=True)
            for country_name, medals in filtered_countries:
                print(f"- {country_name} received {medals}")
        elif command == 'f':
            medal_type = read_medal_type()
            threshold = read_positive_integer()
            print("Countries that received fewer than", threshold, medal_type, "medals:")
            filtered_countries = filter_countries_by_medal(countries, medal_type, threshold, more=False)
            for country_name, medals in filtered_countries:
                print(f"- {country_name} received {medals}")
        elif command == 'e':
            filename = input("Enter the file name to export (.json): ")
            with open(filename, 'w') as file:
                json.dump({name: json.loads(country.to_json()) for name, country in countries.items()}, file, indent=4)
            print(f"File '{filename}' correctly saved.")
        else:
            print("Unknown command, please try again.")


filepath = 'medals.csv'
countries = parse_medals_csv(filepath)
main_loop(countries)


