# Activity 2 - A Shopping System Prototype

#2.1 Defining the domain classes
import json

# 2.1.1 Attributes
class Product:
    def __init__(self, name, price, quantity, unique_identifier, brand):
        self.name = name
        self.price = float(price)
        self.quantity = int(quantity)
        self.unique_identifier = unique_identifier
        self.brand = brand

# 2.1.2 to json() method
    def to_json(self):
        return {
            'name': self.name,
            'price': self.price,
            'quantity': self.quantity,
            'unique identifier': self.unique_identifier,
            'brand': self.brand
        }

# 2.1.3 Subclasses
class Clothing(Product):
    def __init__(self, name, price, quantity, unique_identifier, brand, size, material):
        super().__init__(name, price, quantity, unique_identifier, brand)
        self.size = size
        self.material = material

    def to_json(self):
        product_json = super().to_json()
        product_json.update({
            'size': self.size,
            'material': self.material
        })
        return product_json

class Food(Product):
    def __init__(self, name, price, quantity, unique_identifier, brand, expiry_date, gluten_free, vegan):
        super().__init__(name, price, quantity, unique_identifier, brand)
        self.expiry_date = expiry_date
        self.gluten_free = gluten_free
        self.vegan = vegan

    def to_json(self):
        product_json = super().to_json()
        product_json.update({
            'expiry date': self.expiry_date,
            'gluten free': self.gluten_free,
            'vegan': self.vegan
        })
        return product_json

class Car(Product):
    def __init__(self, name, price, quantity, unique_identifier, brand, year_of_production, mileage, fuel_type, color, transmission):
        super().__init__(name, price, quantity, unique_identifier, brand)
        self.year_of_production = year_of_production
        self.mileage = mileage
        self.fuel_type = fuel_type
        self.color = color
        self.transmission = transmission

    def to_json(self):
        product_json = super().to_json()
        product_json.update({
            'year of production': self.year_of_production,
            'mileage': self.mileage,
            'fuel type': self.fuel_type,
            'color': self.color,
            'transmission': self.transmission
        })
        return product_json

# 2.2 The shopping system
class ShoppingCart:
    def __init__(self):
        self.products = []
        self.unique_identifiers = set()

    def add_product(self, product):
        if product.unique_identifier in self.unique_identifiers:
            print("Error: Product with this unique identifier already exists.")
            return False
        self.products.append(product)
        self.unique_identifiers.add(product.unique_identifier)
        print(f"The product {product.name} has been added to the cart.")
        return True

    def remove_product(self, unique_identifier):
        if unique_identifier not in self.unique_identifiers:
            print("No product found with that identifier. No removal has occurred.")
            return False
        self.products = [p for p in self.products if p.unique_identifier != unique_identifier]
        self.unique_identifiers.remove(unique_identifier)
        print("Product removed.")
        return True

    def get_contents(self):
        products_sorted = sorted(self.products, key=lambda x: x.name)
        summary = []
        for product in products_sorted:
            summary.append(f"{product.name} - Quantity: {product.quantity} - Price: £{product.price}")
        return "\n".join(summary)

    def change_product_quantity(self, unique_identifier, new_quantity):
        for product in self.products:
            if product.unique_identifier == unique_identifier:
                product.quantity = new_quantity
                print(f"The quantity of {product.name} has been updated to {new_quantity}.")
                return True
        print("No product found with that identifier. No changes made.")
        return False

    def export_to_json(self):
        return json.dumps([prod.to_json() for prod in self.products], indent=4)

def validate_unique_identifier(unique_identifier):
    return unique_identifier.isdigit() and len(unique_identifier) == 13

def main():
    cart = ShoppingCart()
    print(" Insert the next command: H")

    command = ''
    while command.lower() != 't':
        command = input("Type your next command: ").lower()
        if command == 'a':
            print("Adding a new product:")
            product_type = input("Insert its type (Clothing, Food, Car): ").lower()
            while product_type not in ['clothing', 'food', 'car']:
                print("Invalid product type. Please enter 'Clothing', 'Food', or 'Car'.")
                product_type = input("Insert its type (Clothing, Food, Car): ").lower()

            name = input("Insert its name: ")
            price = input("Insert its price (£): ")
            while not price.replace('.', '', 1).isdigit():
                print("Invalid price. Please enter a numeric value.")
                price = input("Insert its price (£): ")

            quantity = input("Insert its quantity: ")
            while not quantity.isdigit():
                print("Invalid quantity. Please enter an integer.")
                quantity = input("Insert its quantity: ")

            brand = input("Insert its brand: ")
            unique_identifier = input("Insert its unique identifier (13 digits): ")
            while not (validate_unique_identifier(unique_identifier) and unique_identifier not in cart.unique_identifiers):
                if not validate_unique_identifier(unique_identifier):
                    print("Invalid unique identifier. It must be a 13-digit numeric string.")
                else:
                    print("This unique identifier is already used. Please enter a different one.")
                unique_identifier = input("Insert its unique identifier (13 digits): ")

            if product_type == 'clothing':
                size = input("Insert its size: ")
                material = input("Insert its material: ")
                product = Clothing(name, float(price), int(quantity), unique_identifier, brand, size, material)
            elif product_type == 'food':
                expiry_date = input("Insert its expiry date: ")
                gluten_free = input("Is it gluten free? (True/False): ").capitalize()
                while gluten_free not in ['True', 'False']:
                    print("Invalid input. Please enter 'True' or 'False'.")
                    gluten_free = input("Is it gluten free? (True/False): ").capitalize()
                vegan = input("Is it suitable for vegans? (True/False): ").capitalize()
                while vegan not in ['True', 'False']:
                    print("Invalid input. Please enter 'True' or 'False'.")
                    vegan = input("Is it suitable for vegans? (True/False): ").capitalize()
                product = Food(name, float(price), int(quantity), unique_identifier, brand, expiry_date, gluten_free == 'True', vegan == 'True')
            elif product_type == 'car':
                def is_valid_year(year):
                    if year.isdigit() and len(year) == 4 and int(year) <= 2023:
                        return True
                    return False

                while True:
                    year_of_production = input("Insert the year of production (up to 2023): ")
                    if is_valid_year(year_of_production):
                        year_of_production = int(year_of_production)
                        break
                    else:
                        print("Invalid year of production. Please enter a valid four-digit year no later than 2023.")
                mileage = input("Insert its mileage: ")
                while not mileage.replace('.', '', 1).isdigit():
                    print("Invalid mileage. Please enter a valid number.")
                    mileage = input("Insert its mileage: ")
                fuel_type = input("Insert its fuel type: ")
                color = input("Insert its color: ")
                transmission = input("Insert its transmission type: ")
                product = Car(name, float(price), int(quantity), unique_identifier, brand, int(year_of_production), float(mileage), fuel_type, color, transmission)
            cart.add_product(product)

        elif command == 'r':
            unique_identifier = input("Enter the unique identifier of the product to remove: ")
            cart.remove_product(unique_identifier)

        elif command == 's':
            print("Summary of the cart:")
            print(cart.get_contents())

        elif command == 'q':
            unique_identifier = input("Enter the unique identifier of the product to change quantity: ")
            new_quantity = input("Enter the new quantity: ")
            while not new_quantity.isdigit():
                print("Invalid quantity. Please enter an integer.")
                new_quantity = input("Enter the new quantity: ")
            if not cart.change_product_quantity(unique_identifier, int(new_quantity)):
                print("No product found with that identifier. No changes made.")

        elif command == 'e':
            print("Exporting the cart contents to JSON:")
            print(cart.export_to_json())

        elif command == 'h':
            print(" The program supports the following commands:\n [A] Add a new product to the cart,\n [R] Remove a product from the cart,\n [S] Print cart summary of the cart,\n [Q] Change the quantity of a product,\n [E]  Export a JSON version of the cart,\n [T] Terminate the program,\n [H] List the supported commands")

        elif command == 't':
            print("Terminating the program.")
            break  # Explicit break to ensure the program exits

        else:
            print("Command not recognised. Please try again.")

    print("Goodbye.")

if __name__ == "__main__":
    main()